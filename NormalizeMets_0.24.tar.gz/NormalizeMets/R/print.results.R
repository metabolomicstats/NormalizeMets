print.results <- function(x, ...)
{
  print(dataview(x$results))
  
}
